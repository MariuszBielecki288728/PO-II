﻿using System;

namespace Projekt
{
    class MyViewMode
    {
        public DateTime Termin { get; set; }
        public string Nazwa { get; set; }
        public double Wartość { get; set; }
        public string Kategoria { get; set; }
    }
}
